from setuptools import setup

setup(name='distributions_nd_mestevam',
      version='0.2',
      description='Gaussian distributions',
      packages=['distributions_nd_mestevam'],
      author = 'Marcelo Estevam',
      authoremail = 'marcelo.a.estevam@gmail.com',
      zip_safe=False)
