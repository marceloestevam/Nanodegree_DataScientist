
### Table of Contents

1. [Installation](#installation)
2. [Project Motivation](#motivation)
3. [File Descriptions](#files)
4. [Results](#results)
5. [Licensing, Authors, and Acknowledgements](#licensing)

## Installation <a name="installation"></a>

Type in a pyhton terminal:

from distribution_nd_mestevam import Gaussian, Binomial

The code should run with no issues using Python versions 3.*.

## Project Motivation<a name="motivation"></a>

Learn how to publish a python package


## File Descriptions <a name="files"></a>

Files containing the definifition of a classes for a Gaussian distribution, a Binomial distribuition and a generic distribution
## Results<a name="results"></a>


## Licensing, Authors, Acknowledgements<a name="licensing"></a>

Feel free to use the code here as you would like! 
